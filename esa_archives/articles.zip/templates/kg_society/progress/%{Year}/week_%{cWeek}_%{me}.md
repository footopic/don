---
title: "week_%{cWeek}_%{me}"
category: templates/kg_society/progress/%{Year}
tags: 
created_at: 2015-11-13 15:32:04 +0900
updated_at: 2015-11-23 16:33:57 +0900
published: true
---

先週の報告: #kg_society/%{me}

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
|  |  |

### 先週こなしたタスク :smile:

### 先週から持ち越したタスク:neutral_face: 


<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
### {タスク名}
### {期限}
### どこで困っているか
（困っているところ）

<!--
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

