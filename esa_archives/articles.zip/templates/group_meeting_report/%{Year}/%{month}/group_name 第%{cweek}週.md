---
title: "group_name 第%{cweek}週"
category: templates/group_meeting_report/%{Year}/%{month}
tags: 
created_at: 2015-11-05 19:59:18 +0900
updated_at: 2015-11-05 19:59:18 +0900
published: true
---

# 報告事項
<!-- ex. 柴原が○○学会へ申込完了  -->
TODO: 

# 問題点
<!-- ex. 柴原の論文締切が明後日（実際の日にち）なのに、音信不通 -->
TODO: 

# 参加者
TODO: 
<!--
* B4
    * 柴原
    * 高橋
  -->

<!-- その他、何かあれば章分けし書くこと -->
