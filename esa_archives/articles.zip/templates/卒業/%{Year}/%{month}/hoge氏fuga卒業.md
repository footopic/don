---
title: "hoge氏fuga卒業"
category: templates/卒業/%{Year}/%{month}
tags: 
created_at: 2015-10-01 18:42:15 +0900
updated_at: 2015-10-01 18:44:20 +0900
published: true
---


# [卒業に向けて一言]

