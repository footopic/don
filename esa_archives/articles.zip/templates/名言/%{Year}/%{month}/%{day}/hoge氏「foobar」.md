---
title: "hoge氏「foobar」"
category: templates/名言/%{Year}/%{month}/%{day}
tags: 
created_at: 2015-09-18 12:12:47 +0900
updated_at: 2015-09-28 01:31:01 +0900
published: true
---

# 備考
foobar
