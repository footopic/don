---
title: "iwAincrad"
category: 語録
tags: 
created_at: 2015-10-08 11:31:20 +0900
updated_at: 2015-10-08 11:31:20 +0900
published: true
---

## iwAincrad
Minecraft が動いているサーバー名
http://minecraft.cps-lab.private:8123

## 全体図
![Aincard_in_ALO.png (1.7 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/10/08/5955/560a9638-5a16-4c96-b0fd-bec2ee78dec8.png)

