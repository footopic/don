---
title: "Ingress"
category: 
tags: 
created_at: 2015-10-02 13:27:33 +0900
updated_at: 2015-10-02 13:31:14 +0900
published: true
---

#Ingress
[Mission Day is coming to Japan this Saturday, October 3rd!](https://plus.google.com/+Ingress/posts/8ZhbDQHHYNQ)
-ミッションデイ行きたい...行きたくない？
