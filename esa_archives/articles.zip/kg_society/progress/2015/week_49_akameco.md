---
title: "week_49_akameco"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-30 16:42:24 +0900
updated_at: 2015-11-30 16:57:10 +0900
published: true
---

先週の報告: #kg_society/akameco

# 進捗報告

### タスク 
- esa.io代替→えるざっぷとRails書いた(途中)
- gitlabのイシュー殺しまくった
- bot書いてない

## 最も困っているタスク

Pythonきもい...たすけて....

輪講→バリバリフォーマットでいい？
