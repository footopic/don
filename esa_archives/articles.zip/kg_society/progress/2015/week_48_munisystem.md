---
title: "week_48_munisystem"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-23 16:38:04 +0900
updated_at: 2015-11-23 16:50:49 +0900
published: true
---

先週の報告: [kg_society/progress/2015/week_47_munisystem](/posts/243)

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
|  |  |

### 先週こなしたタスク :smile:
- かわいいIOT  
グダグダだったのでプロジェクト凍結しました。  
プロジェクト凍結でいいけどPPの意見がほしい的な話が来ているので別途対応します。

### 先週から持ち越したタスク:neutral_face: 
輪行

<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
なし
