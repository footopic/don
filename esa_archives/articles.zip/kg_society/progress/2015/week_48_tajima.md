---
title: "week_48_tajima"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-23 16:40:42 +0900
updated_at: 2015-11-23 16:40:43 +0900
published: true
---

先週の報告: #kg_society

# 進捗報告

### 新規タスク :sob: 
（もう修論しないといけ）ないです

### 先週こなしたタスク :smile:
| タスク | 期限 |
| ---- | ---- |
| 工学院のphp環境用box作った(Vagrant) |  |
| 内定式行ってきた |  |
| 内定報告書を学科ページにだした |  |

### 先週から持ち越したタスク:neutral_face: 
| タスク | 期限 |
| ---- | ---- |
| 修論に使うサーバ実装 | 先週末:fire: |
| G空間EXPO出展 | 11/25（出展11/26-28） |

![Selection_006.png (39.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/6555/16777d2b-56f0-4bb2-9157-440c289bb1ad.png)

