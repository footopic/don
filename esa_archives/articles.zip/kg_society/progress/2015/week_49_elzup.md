---
title: "week_49_elzup"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-30 16:42:48 +0900
updated_at: 2015-11-30 16:43:31 +0900
published: true
---

先週の報告: #kg_society/elzup

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
| [候補: HCS研究会](http://www.ieice.org/~hcs/wiki/index.php?2016年3月研究会) |  |
| 論文読む |  |

### 先週こなしたタスク :smile:
| タスク | 期限 |
| ---- | ---- |
|  |  |

### 先週から持ち越したタスク:neutral_face: 
| タスク | 期限 |
| ---- | ---- |
| footopic |  |
| 卒論 |  |


<!--
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

