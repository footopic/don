---
title: "week_46_tajima"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-15 21:09:08 +0900
updated_at: 2015-11-15 21:09:08 +0900
published: true
---

# 前回の報告
#/kg_society/progress/2015/tajima

te
# 進捗報告

| 項目 | 現状 | 期限 |
| --- | --- | --- |
| te | s | t |


<!--
進捗を象徴する画像を最低一枚
-->

