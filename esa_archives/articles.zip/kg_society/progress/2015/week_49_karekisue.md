---
title: "week_49_karekisue"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-30 16:39:16 +0900
updated_at: 2015-11-30 16:45:14 +0900
published: true
---

先週の報告: #kg_society/karekisue

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
|  |  |

### 先週こなしたタスク :smile:
艦これ秋イベント

![kancolle_20151123_115900.png (637.2 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/30/5958/9f417363-0fb3-4ba8-afcf-ca415b7242bf.png)

![kancolle_20151125_232051.png (689.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/30/5958/0a3c617e-2696-4d67-aab4-4ef43acb4413.png)


### 先々週こなしたタスク :smile:
ET/IoT2015で組み込みとそれに関する業界の知見を広めた

### 先週から持ち越したタスク:neutral_face: 


<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
NICTプロジェクトの全体の流れがわからなすぎる
また話を聞かなければいけないと思う
### {タスク名}
### {期限}
### どこで困っているか
（困っているところ）

<!--
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

