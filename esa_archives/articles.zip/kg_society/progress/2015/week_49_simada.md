---
title: "week_49_simada"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-30 16:43:58 +0900
updated_at: 2015-11-30 16:43:58 +0900
published: true
---

先週の報告: [#283:  kg_society/progress/2015/week_48_simada](/posts/283) /simada

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
|  |  |

### 先週こなしたタスク :smile:
輪講

### 先週から持ち越したタスク:neutral_face: 
輪講

<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
### {タスク名}
### {期限}
### どこで困っているか
（困っているところ）

<!--
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

