---
title: "week_49_munisystem"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-30 16:42:08 +0900
updated_at: 2015-11-30 16:44:20 +0900
published: true
---

先週の報告: [kg_society/progress/2015/week_48_munisystem](/posts/278)

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
| zabbixの導入 | 12月末 |

### 先週こなしたタスク :smile:
輪講

### 先週から持ち越したタスク:neutral_face: 
なし

<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
### なし

<!--
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

