---
title: "week_47_nnk"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-18 13:55:33 +0900
updated_at: 2015-11-18 14:13:57 +0900
published: true
---

<!--

kg_society用の進捗報告テンプレです
進捗を象徴する画像を最低一枚入れてね



タスクに関して
新規等各分類で、ないならなしでも良いです
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

# 進捗報告

### 新規タスク :sob: 
| タスク | 期限 |
| ---- | ---- |
|  徘徊児童調査|11/27小学校訪問  |

### 先週こなしたタスク :smile:
####クリニックの椅子塗替え（4/18）
![DSC_0085.JPG (839.7 kB, orientation fixed)](https://img.esa.io/uploads/production/attachments/2152/2015/11/18/6159/96f202e1-047e-46a8-8b99-a0929cf16e59.JPG)

####偽りの仮面クリア
![偽りの仮面](http://stat001.ameba.jp/user_images/20151008/18/tensan1031/a8/1c/j/o0800045313447997422.jpg)
### 先週から持ち越したタスク:neutral_face: 
クリニックの椅子塗替え残り14本(11/27まで)
卒論全く手を付けてない
アンドロイドアプリ制作細かい挙動の作りこみを11/20までに




