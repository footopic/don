---
title: "week_47_karekisue"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-16 16:45:52 +0900
updated_at: 2015-11-17 03:57:03 +0900
published: true
---

<!--

kg_society用の進捗報告テンプレです
進捗を象徴する画像を最低一枚入れてね

タスクに関して
新規等各分類で、ないならなしでも良いです
コピペ用テーブル

| タスク | 期限 |
| ---- | ---- |

-->

# 進捗報告

###イベント:sob:
ET/IoTテクノロジー
http://www.jasa.or.jp/expo/

### 新規タスク :sob: 
| タスク | 期限 |
| ----|----|
|SFCからNTTに渡すデータの精査・打ち込み| 今週中！！ |
|  ---- | ----  |

### 先週こなしたタスク :smile:

・慶応SFCで5時間ぼっちで作業した，優しかった．

・うたわれるもの 偽りの仮面
<!--
![gomennnasaidesu.jpg (100.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/1a3d39b1-7da6-491c-97ea-6414a260bc86.jpg)
-->


<img  src= "https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/1a3d39b1-7da6-491c-97ea-6414a260bc86.jpg"alt="ネコネ金" title =死因なのです width="480" height="272" />

・デレステで違法課金に成功した
<!--
![違法課金.png (450.2 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/40758a38-5661-47a0-8419-edf4b1c700cb.png)
-->
<img  src= "https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/40758a38-5661-47a0-8419-edf4b1c700cb.png"alt="違法課金" title =違法課金 width="360" height="640" />

### 先週から持ち越したタスク:neutral_face: 


<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
### {タスク名}
### {期限}
### どこで困っているか
（困っているところ）



