---
title: "week_48_akameco"
category: kg_society/progress/2015
tags: 
created_at: 2015-11-23 16:40:32 +0900
updated_at: 2015-11-23 16:47:52 +0900
published: true
---

先週の報告: [#280:  kg_society/progress/2015/week_47_akameco](/posts/245) 

# 進捗報告

### 新規タスク :sob: 
| タスク | 状態 |期限 |
| --- | ---- | --- |
| slackにメール流す奴 | WIP  | 今週中(にやりたい) |
| slackにfacebook流す奴 | WIP  | 今週中(にやりたい) |
| 学科HP引き継ぎ | WIP  | 知らない |

### 先週こなしたタスク :smile:

ORF行った

### 先週から持ち越したタスク:neutral_face: 
論文読んでない

<!-- もっとも困っているタスクで質問 なくてもよい -->
## 最も困っているタスク
### {タスク名}
### {期限}
### どこで困っているか

## etc
神奈川終焉を迎えたので(詳しくはむに)、B3全体でタスクが空いた感じがある
