---
title: "SUZURIラボ製品(飽きてきた)"
category: CPS_Goods
tags: 
created_at: 2015-10-21 16:12:58 +0900
updated_at: 2015-10-21 16:46:42 +0900
published: true
---

https://suzuri.jp/sukonbu0909

<img width="1245" alt="Screen Shot 2015-10-21 at 16.15.43.png (1.8 MB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/10/21/5955/7cccb7b8-2282-4f56-8197-b8544b07912b.png">

