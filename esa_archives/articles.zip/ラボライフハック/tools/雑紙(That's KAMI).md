---
title: "雑紙(That's KAMI)"
category: ラボライフハック/tools
tags: 
created_at: 2015-09-20 14:35:52 +0900
updated_at: 2015-09-20 16:07:48 +0900
published: true
---

雑紙が欲しい時は3Dプリンタの上の棚にあるので使ってください

![IMG_4616.jpg (87.3 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/09/20/5955/aefff43b-61eb-4471-9622-77ef8865d100.jpg)

A3 のでかい紙やB6の小さい紙も入ってます
