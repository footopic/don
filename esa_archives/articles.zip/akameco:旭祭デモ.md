---
title: "akameco:旭祭デモ"
category: 
tags: 
created_at: 2015-11-01 20:51:14 +0900
updated_at: 2015-11-05 14:13:15 +0900
published: true
---

旭祭のデモで音声認識をした文章をネガティブ判定するものをつくった。

<img width="977.28" alt="asahi1.png (2.7 MB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/01/6061/b3dcf8f6-f95e-4d05-9c09-f4362f6a155e.png">

<img width="1148.1599999999999" alt="asahi2.png (180.9 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/01/6061/4b9e7702-9260-4b4f-b31d-8380e4fc6f5b.png">

[デモアプリ](http://oc2015.akameco.pw/)

上記のリンクから遊べる。

スタートボタンを押すと、音声認識がはじまる。
なお、Chrome以外では動作しない。



形態素解析はkuromoji.jsを利用した。
サバーサイドはnode.jsでexpress。
リロードをしたくなかったので、websocketでリアルタイム描画してる。
websocketはsocket.ioライブラリから利用。

フロント側は、jQuery(あまり使いたくはないけど)

ネガポジ判定に単語感情極性対応表を使った。

[PN Table](http://www.lr.pi.titech.ac.jp/~takamura/pndic_ja.html)

語彙ネットワークを利用して自動的に計算された値なので、結果に違和感を覚えることが多々ある。

ymd先生にデモを見てもらって、オタク文化圏の感情判定をどうするかみたいな話をした。
一般的に気持ち悪いネガティブな言葉でもオタク文化だと、ポジティブな言葉として利用されることが多々ある。
そこで、精度のよい辞書を生成するためにはどうするかという話をした。(結論は出てない)



