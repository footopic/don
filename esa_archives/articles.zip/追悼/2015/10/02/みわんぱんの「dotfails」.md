---
title: "みわんぱんの「dotfails」"
category: 追悼/2015/10/02
tags: 
created_at: 2015-10-02 21:38:08 +0900
updated_at: 2015-10-03 10:53:12 +0900
published: true
---

# dot **fails** /, dotfails/.bashrc

| 項目 | 値 |
|---|---|
| 死亡時刻 | 不明n |
| 発見場所 |ゴミ箱 |
| 状態 |  |
| 備考 | `mv dot{fails,files}` |
