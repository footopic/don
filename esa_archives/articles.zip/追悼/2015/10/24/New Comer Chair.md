---
title: "New Comer Chair"
category: 追悼/2015/10/24
tags: 
created_at: 2015-10-24 21:35:23 +0900
updated_at: 2015-10-24 21:37:49 +0900
published: true
---

# [New Comer Chair]

| 項目 | 値 |
|---|---|
| 死亡時刻 | 組み立て初めて5分 |
| 発見場所 |らぼ |
| 状態 |  ネジとパーツが明らかに足りない|
