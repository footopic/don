---
title: "02 Black Balloon"
category: CPSIoT
tags: 
created_at: 2015-11-03 15:03:07 +0900
updated_at: 2015-11-05 01:22:31 +0900
published: true
---

![blackballoon.png (23.5 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/03/6099/ce86c07e-4afe-46da-839d-39ca9f125f03.png)

# 機能
ラボの様子がスマートフォン＆Webページから確認できる。

# 使用方法
岩井研ネットに繋いでアプリを起動するだけ（簡単！）
以下のリンクか各カメラの様子も確認可能（PCからも！）
[11F Camera1](http://iot.cps-lab.private/blackballoon/camera0)
[11F Camera2](http://iot.cps-lab.private/blackballoon/camera1)  
```※現在カメラが11Fのしか設置されていないが、今後14Fにも設置予定 ```

# インストール方法
スマートフォンで下のリンクからアプリをインストールできます。（cpsアカウントが必要です）
[https://drive.google.com/open?id=0Byb9iZJldEGWaDUxVW5YQTdPLVk](https://drive.google.com/open?id=0Byb9iZJldEGWaDUxVW5YQTdPLVk)

# 製作者
* 柴原
    * APIサーバ、Androidアプリ
* 高橋
    * アイコン画像、RaspberryPiケース

# リポジトリリンク
[http://gitlab.cps.im.dendai.ac.jp/cps/BlackBalloonAndroid](http://gitlab.cps.im.dendai.ac.jp/cps/BlackBalloonAndroid)
