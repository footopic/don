---
title: "01 AbsoluteDuo"
category: CPSIoT
tags: 
created_at: 2015-10-30 03:21:53 +0900
updated_at: 2015-11-10 16:45:40 +0900
published: true
---

![speaker_icon.png (15.7 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/03/6099/1a5e4a23-c0f4-443c-b623-895fcaed52a9.png)

# 機能
テレビの横のスピーカーをスマートフォンからOnOffできる。

# 使用方法
岩井研のネットに繋いで、ボタンを押すだけ（簡単！）
以下のリンクのWebアプリでも使用可能（PCからも！）
[http://iot.cps-lab.private/absoluteduo/](http://iot.cps-lab.private/absoluteduo/)

# インストール方法
スマートフォンで下のリンクからアプリをインストールできます。（cpsアカウントが必要です）
[https://drive.google.com/open?id=0Byb9iZJldEGWTEQzSzZtU0h4djQ](https://drive.google.com/open?id=0Byb9iZJldEGWTEQzSzZtU0h4djQ)

#製作者
* 野中
    * ハードウェア、APIサーバ
* 高橋
    * Webページ
* 柴原
    * Androidアプリ、Icon

# リポジトリリンク
[http://gitlab.cps.im.dendai.ac.jp/cps/AbsoluteDuoAndroid](http://gitlab.cps.im.dendai.ac.jp/cps/AbsoluteDuoAndroid)
