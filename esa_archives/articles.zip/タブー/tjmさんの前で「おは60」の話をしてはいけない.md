---
title: "tjmさんの前で「おは60」の話をしてはいけない"
category: タブー
tags: 
created_at: 2015-10-25 17:46:52 +0900
updated_at: 2015-10-25 17:47:03 +0900
published: true
---

ありがたいお話が始まってしまう
