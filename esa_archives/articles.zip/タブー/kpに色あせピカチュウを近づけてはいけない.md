---
title: "kpに色あせピカチュウを近づけてはいけない"
category: タブー
tags: 
created_at: 2015-10-28 13:08:40 +0900
updated_at: 2015-10-28 13:17:45 +0900
published: true
---


