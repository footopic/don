---
title: "BlackTimer"
category: CPS_Scripts
tags: 
created_at: 2015-10-07 14:29:48 +0900
updated_at: 2015-10-07 17:03:03 +0900
published: true
---

http://blacktimer.elzup.xyz/

# Usage:
## 1時間タイマー

http://blacktimer.elzup.xyz/?name=Sotsuron

## 締め切りタイマー
http://blacktimer.elzup.xyz/?name=Mike&end-time=2015-12-31T23:59:59

## うまるx6
http://blacktimer.elzup.xyz/?name=Hello&un=6

:octocat: Github: https://github.com/elzzup/black_timer
