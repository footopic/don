---
title: "ochinpo.py"
category: CPS_Scripts
tags: 
created_at: 2015-10-06 16:07:41 +0900
updated_at: 2015-10-06 16:26:25 +0900
published: true
---


原案者: @yokota_1442036084 
ランダムに一文字を出力し `オチンポ` が出たら回数を表示

`Python 3.5.0`
```python
import random

queue = '．．．．'
word = 'オチンポ'
c = 0
while queue != word:
    ch = word[random.randrange(len(word))]
    print(ch, end="")
    c += 1
    queue = queue[1:] + ch
print()
print(str(c) + '回目で果てました')
```

ポポチンチンポンポチポチオンンンオンポポチポオオンンンオオポチオンオチオチンポ
39回目で果てました
