---
title: "yuruyuri.com"
category: CPS_Scripts
tags: 
created_at: 2015-10-06 02:54:36 +0900
updated_at: 2015-10-06 02:54:37 +0900
published: true
---


### 1. http://yuruyuri.com/ にアクセス
### 2. コンソールを開く
### 3. 下のJSを実行  

```js
$('.bg-rotate').attr('src', 'http://www.cps.im.dendai.ac.jp/index.php?plugin=ref&page=Downloads&src=nairegift%E8%83%8C%E6%99%AF%E9%80%8F%E6%98%8E.png')
```

### 4. happy

![Screen Shot 2015-10-06 at 02.53.20.png (2.7 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/10/06/5955/262f7ce7-9c14-4770-a0b7-cc5bd1ed8d5a.png)

