---
title: "syougun.sh"
category: CPS_Scripts
tags: 
created_at: 2015-10-02 02:10:37 +0900
updated_at: 2015-10-03 21:41:38 +0900
published: true
---

#git push origin master<br> するたびに暴れん坊将軍を召喚しよう！

手順
* まずUbuntuを用意します
* ここからスクリプトをDLします→[ワイのGithub](https://github.com/mikekuroe/syougun)
* bash syougun.sh　[aliasを入れてもいいrcファイル]　を叩きます
* カレンドディレクトリ上のMusicフォルダに「syougun.mp3」を入れます
* 準備OK！さあ皆もsyougunコマンドで暴れん坊将軍になろう！（意味深）

