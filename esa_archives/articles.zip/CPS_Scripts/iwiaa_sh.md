---
title: "iwiaa.sh"
category: CPS_Scripts
tags: 
created_at: 2015-09-21 13:22:12 +0900
updated_at: 2015-09-21 13:22:12 +0900
published: true
---

`iwiaa` 岩井先生の AA を出力するコマンド
npm: https://libraries.io/npm/iwiaa

# Install
```
npm install iwiaa
```


# Usage
```bash
iwiaa
```


![Screen Shot 2015-09-21 at 13.21.12.png (288.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/09/21/5955/b54c48e5-d89b-4f95-af1e-1e69bf4c3707.png)

