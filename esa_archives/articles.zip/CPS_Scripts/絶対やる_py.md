---
title: "絶対やる.py"
category: CPS_Scripts
tags: 
created_at: 2015-09-21 13:18:04 +0900
updated_at: 2015-09-27 18:22:40 +0900
published: true
---

絶対やらないを作り出す関数
Gist: https://gist.github.com/elzzup/a19c40ddd13d25451688

# Source
```python:say_not_do.py
# -*- coding: utf-8 -*-
def say_not_do(verb, sub=None):
    text = verb * 4
    text += ("絶対%s！" % verb) * 2
    if sub:
        text += "(%s)" % sub
    return text
```

# Usage
```python
verb = "見る"
print(say_not_do(verb))
# => 見る見る見る見る絶対見る！絶対見る！


verb = "やる"
sub = "やらない"
print(say_not_do(verb, sub))
# => やるやるやるやる絶対やる！絶対やる！(やらない)
```
