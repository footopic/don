---
title: "society 第4週"
category: group_meeting_report/2015/11
tags: 
created_at: 2015-11-19 23:34:00 +0900
updated_at: 2015-11-19 23:34:00 +0900
published: true
---

# 報告事項
* 各自の報告: [kg_society 47](/posts?q=in:kg_society/progress/2015++week_47)
* かわいいIoT プロジェクトを問題視している人が多い
* グループミーティングの時間は月曜日の5限目
<!-- ex. 柴原が○○学会へ申込完了  -->

# 問題点
* **:fire: かわいいIoT :fire:**
* <意見> どんな学会に誰が出ているのかが把握できる場所がほしい

# 論文記事紹介
## 田島
* [地理院タイルについて](http://www.slideshare.net/hfu/foss4g-27808866)
* [匿名化について](http://www.r.dl.itc.u-tokyo.ac.jp/node/57)

## 高橋
* [C＆Cユーザーフォーラム＆iEXPO2015：NEC、防犯カメラに映る混雑状況“見える化”技術　人の流れから異常を検知 - ITmedia](http://www.itmedia.co.jp/news/articles/1511/11/news146.html)
* [カンファレンスプログラム | 進化する組込み技術とIoT技術の総合展／Embedded Technology & IoT Technology 同時開催！](http://www.jasa.or.jp/expo/conf/)

# 議題
* 今回集まってみて縦割りについてどうするか？
    * 縦割りはなし
    * グループミーティング月曜日5限に行う, ほかは個別
* グループミーティングにそれぞれの研究についての評価を組み込みたい
    * 進捗報告でやっていけそう
* 週報について
    * 今回のやり方が良さそう


# 参加者
* M2 田島
* M1 末吉,津野
* B4 高橋, 日向
* B3 安達,諸沢, 神山, 齋藤 ,嶋田

<!-- その他、何かあれば章分けし書くこと -->
