---
title: "society 第5週"
category: group_meeting_report/2015/11
tags: 
created_at: 2015-11-27 10:29:36 +0900
updated_at: 2015-11-27 11:18:16 +0900
published: true
---

# 報告事項
<!-- ex. 柴原が○○学会へ申込完了  -->
田島さん: G空間Expo 出展

# 問題点

# 参加者
* M2 田島
* M1 
* B4 高橋, 野中, 日向
* B3 神山, 嶋田, 齋藤 , 諸沢, 安達

<!-- その他、何かあれば章分けし書くこと -->
