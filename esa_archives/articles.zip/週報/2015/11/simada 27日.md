---
title: "simada 27日"
category: 週報/2015/11
tags: 
created_at: 2015-11-27 09:27:40 +0900
updated_at: 2015-11-27 16:03:48 +0900
published: true
---

先週: [#261:  週報/2015/11/simada 20日](/posts/261) 

# 今週の作業内容
<!--
## hoge
foo
-->
## 輪講
アブストとイントロは訳した

# 知見
<!--
* hoge
* fuga
-->
ORFすごかった
    

# 発生した問題
<!--
## hoge
foo
-->

# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```
## :fire: 輪講
できる限り訳して発表したい
最悪全部訳しきれないかも

# 所感
輪講１週間伸びてよかった


<!-- 週報 template v1.0 -->
