---
title: "elzup 15日"
category: 週報/2015/11
tags: 
created_at: 2015-11-16 05:02:53 +0900
updated_at: 2015-11-17 23:28:39 +0900
published: true
---

<!-- 先週へのリンク入れて！ -->
先週: [#211:  週報/2015/11/elzup 08日](/posts/211) 

# 今週の作業内容
## CodeFestival2015 楽しんできました！
[codefestival2015 レポート記事](http://elzup.hatenablog.com/entry/code_festival2015_report)
強い人たくさんいて世界が広がった
めちゃくちゃ勉強になった

戦利品(参加賞ばかり)
![IMG_4867.jpg (1.6 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5955/71390e7a-7269-4378-a5b9-369b545ffc70.jpg)

ステッカー(必然的に使うきが起きないものが溜まってく)
![IMG_4871.jpg (1.4 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5955/f4451474-4e55-44f0-998f-b401d471f343.jpg)



2015年参加したイベント(frontrend がボロボロ...)
![IMG_4872 (1).jpg (84.0 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5955/c108b3db-facc-4089-8c2d-4a6a35079358.jpg)




## タウンページデモ再現
昔のソースコードを掘り出して取り敢えず動くところをデモした


# 知見
* 競プロ
    * ツール
    * 解き方
* ショートコーディング

# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```

## :fire: 全国大会アブスト
火曜日までに
![bc673962.jpg (88.9 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5955/0b7024c2-8c45-4806-bcdb-ae6a1b8e7d67.jpg)



## :fire: footopic の進捗
=> nil

## etc
* slack, gitlab:issue 管理をしっかりさせたい

# 進捗表
| タスク名         | 進捗       | 期限         |
|------------------|------------|--------------|
| タウンページデモ | 終了       | 2015/11/13   |
| 卒論             | ノータッチ | 3/1だっけ？  |
| 論文全国大会     | ノータッチ | 11/16        |


# 所感
* 「みんチャレ」というアプリで「アニメ見たら筋トレ」グループを作って筋トレ週間に挑み始めてみた
* フロントエンドの学習と時間を割きたい

<!-- 週報 template v1.0 -->
