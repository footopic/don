---
title: "elzup 22日"
category: 週報/2015/11
tags: 
created_at: 2015-11-23 13:12:42 +0900
updated_at: 2015-11-23 14:23:58 +0900
published: true
---

先週: #/elzup

# 今週の作業内容
## ORF
やはりレベルが高かった
単純なアイデアでも実装して実際にサービス化しているものも多い印象だった
Web サービスとか作ってる [NECO Lab.](http://neco-lab.com/) が気になった

## SIP bootstrap
手伝った


## footopic
ぐだぐだと開発している
タイムリミットはあと一週間
画像管理関連が面倒くさそう
* プロフィール画像の変更
* 記事に画像の挿入

![Screen Shot 2015-11-23 at 12.55.04.png (149.3 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/5955/d0db5755-c341-4054-90ee-451017a8cefb.png)


# 知見


# 発生した問題
起きれない

![59337087-s.jpg (22.1 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/5955/a8ec061c-9638-461a-ba31-3426e1d488b6.jpg)


# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```

# :fire: footopic 
デプロイまで


# 所感
* ズンベロった
* 来週の世にも奇妙な物語楽しみ
* 全体のタスクリストの使い方ががさつになってきた

<!-- 週報 template v1.0 -->
