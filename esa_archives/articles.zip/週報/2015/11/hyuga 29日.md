---
title: "hyuga 29日"
category: 週報/2015/11
tags: 
created_at: 2015-11-30 04:00:06 +0900
updated_at: 2015-11-30 20:57:34 +0900
published: true
---

先週: [#266:  週報/2015/11/hyuga 22日](/posts/266) 

# 今週の作業内容
##卒論
* 梗概をtexで書き直し

## G空間EXPO
* ジオメディアサミット聞きに行った
    * inbound insight
    * ジオどす
    * myThings
    * ABC Lunch

## スクフェス
* 海未ちゃんGET

## デレステ
* きらりx2枚、姉ヶ崎×2枚GET

# 知見
* デレステのお気に入り機能

# 発生した問題
##tex
* レイアウト崩れる

# 来週の作業予定
## :fire:  卒論
* 文章見直す

## :palm_tree: チェックラリー
* ジオフェンス対応

# 今週のトロフィー
![プラチナ](http://psnprofiles.com/lib/img/layout/40-platinum.png) × 00
![ゴールド](http://psnprofiles.com/lib/img/layout/40-gold.png) × 02
![シルバー](http://psnprofiles.com/lib/img/layout/40-silver.png) × 12 
![ブロンズ](http://psnprofiles.com/lib/img/layout/40-bronze.png) × 79

# 所感
トロフィー数から分かるようにゲームしすぎたので来週はアプリちゃんと作る
