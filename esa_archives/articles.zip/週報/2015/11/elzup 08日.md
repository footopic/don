---
title: "elzup 08日"
category: 週報/2015/11
tags: 
created_at: 2015-11-09 17:10:11 +0900
updated_at: 2015-11-14 02:54:15 +0900
published: true
---

# 今週の作業内容

## cps Docker
iot.cps.im.dendai.ac.jp のDocker リバースプロキシ設定


## footopic
https://github.com/footopic

![footopic.png (3.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/09/5955/fc039fe0-12e9-4b4d-8746-3fb7fbc7d4bc.png)

**footprint と topic にかけて footopic**

esa.io の CPS 版作成開始
prototype として rails  + fluxxor で一つのアプリケーションでやってたけど
結局 API と フロントアプリケーションに分割し始めた


## :sparkling_heart: 環境整理 :sparkling_heart: 
https://github.com/elzzup/dotfiles

### vim
.vimrc の分割

```
~/.vim/rc
├── basic.rc.vim
├── encoding.rc.vim
├── init.vim
├── mac.rc.vim
├── mapping.rc.vim
├── plugins
│   ├── align.rc.vim
│   ├── autopep8.rc.vim
│   ├── cpp-vim.rc.vim
│   ├── ...
└── plugins.rc.vim

```

### zsh

```
.zsh/rc
├── alias.zsh
├── basic.zsh
├── envpath.zsh
├── envs
│   ├── android.zsh
│   ├── ...
│   └── vm.zsh
├── helpers
│   ├── background.zsh
│   ├── ...
│   └── print_file.zsh
├── oh-my-zsh.rc.zsh
├── plugins
│   ├── antigen.rc.zsh
│   ├── ...
│   └── percol.rc.zsh
├── plugins.zsh
└── vimbind.zsh
```

### vimperator
次回の firefox の更新でちょっと将来が怪しくなってきた vimperator だけど整理した

```
.vimperator/rc
├── basic.vimp
├── init.vimp
├── js
│   ├── get_short_uri.js
│   ├── ...
│   └── websearch.rc.js
├── mapping.vimp
├── plugins.vimp
└── style.vimp
```


# 知見
* react.js
* fluxxor
* Docker



# 発生した問題
## リバースプロキシ先プロジェクトでの参照問題
前にも抱えたことがある問題
host.com/hoge/ をwebプロジェクトのルートにしたい時に上手くいかない
対応方法: 相対パスにする，または必ずプロジェクトルートを含む絶対パスにする



# 来週の作業予定
<!--
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
-->

## :fire::fire: 感情解析 Map

## footopic
基本機能の実装完了
# 所感
lab issue を活発にしていきたい

先週: https://cps.esa.io/posts/201

