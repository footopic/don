---
title: "zuka 30日"
category: 週報/2015/11
tags: 
created_at: 2015-11-30 14:27:12 +0900
updated_at: 2015-11-30 17:21:26 +0900
published: true
---

先週: #/zuka

# 今週の作業内容
## Android×Unity
UnityのAndroidアプリケーションを作成してAndroidの独自機能の呼び出しの実装。
Androidのセンサー情報をUnityに送信してデータ連携を完了させたよ。

# 知見
* UnityでAndroidの独自機能を呼び出すためにはActivityをオーバーライドする必要があるらしい
* Androidマニフェストも更新必須
* gradle神

# 発生した問題
## Android×Unity
久々にAndroidStudioを使ってライブラリ参照等のやり方を間違えてました…
定期的に触っておかないと忘れてします…


# 来週の作業予定
## :fire: TAKAYARFID
奈良先端に持っていくためAndroidでビルドできるようにする。
余力があればGearVRで見れるようにしたい。
``` 優先: 🔥 後回し:  🌴```

# 所感
モンハン買ったよ！！！！！！！！！！！！！！！！！


<!-- 週報 template v1.0 -->
