---
title: "naoya 08日"
category: 週報/2015/11
tags: 
created_at: 2015-11-08 23:55:56 +0900
updated_at: 2015-11-09 14:23:42 +0900
published: true
---

# 今週の作業内容
## CPS IoT2 
ラボの様子をWebから見れるやつ。
ラズパイとUSBカメラを使った。
中身はPythonのOpenCVで動いている。

## docker入門
良さある

## Android OpenGL 入門
やっと始めた。
頑張って11月中旬までに360°ビューワー完成させなきゃ…

## 黒猫のウィズのイベント
週末が持って行かれた

## 今日のきりんちゃん
こっちのほうがかわいい
![Kirin_2.png (488.3 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/08/6099/d479bded-6d21-4a3e-8b32-e873c9550320.png)



# 知見
* docker画期的だね
* AndroidOpenGLES
* ソシャゲのイベントは闇



# 発生した問題
## nginxのproxy_passの挙動が2種類ある
nginxをリバースプロキシにする場合に使用するproxy_passディレクティブは、完全なURIが与えられた場合と、そうでない場合で挙動が異なる。
詳細は[こちら](http://www.xmisao.com/2014/05/09/nginx-proxy-pass.html)のサイトに詳しく書いてあるので気になる人はみて。

これで2時間くらい詰まった…にわかはっらぃ…

## 松屋のカレーが辛すぎる
あれはダメ。ただ辛いだけ。



# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: 360°ビューワー
AndroidのOpenGLESのお作法に慣れてきた。

## esaの代替案dashiのAndroidApp
Androidアプリも作ることになりそうなのでやりましょ


# 所感
やっぱりバットマンおもしろい。
あと来年公開のおもしろそうな映画（シビル・ウォー 〜アイアンマン　vs　キャプテンアメリカ〜）を見つけて楽しみ。

そんな感じで来週もよろしく。
