---
title: "iwamoto 27日"
category: 週報/2015/11
tags: 
created_at: 2015-11-27 01:19:25 +0900
updated_at: 2015-11-27 16:03:31 +0900
published: true
---

先週: #/iwamoto
https://cps.esa.io/posts/256
# 今週の作業内容
<!--
## hoge
foo
-->
・G空間EXPOに向けて展示アプリの修正
・G空間EXPOでアプリの説明員
・英論輪講
# 知見
<!--
* hoge
* fuga
-->
Xcodeでラベルを扱うときはフォントを[HiraginoSans-W3]にすることで正しく日本語で表示できることがわかった。kpさんありがとう！


# 発生した問題
<!--
## hoge
foo
-->
今日もG空間Expoの説明員を頼まれたのでミーティング出れません。
natural_sensingのミーティングに全く参加できていないので申し訳ないです...
# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```
:fire: 輪講発表が１週間延びたのでより時間を掛けていきたい所存
:palm_tree: 所属チームの論文などを読み進められたらなと思っています

# 所感
29日はデレマスの舞踏会行ってきます！
28日も行きたかった！(弱い)
いろいろと疲れたので赤城みりあちゃんからバブみを感じたい


![20150908112821.jpg (321.3 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/27/6557/b236714b-ba59-4e6f-9e85-237d09703ddc.jpg)

<!-- 週報 template v1.0 -->
