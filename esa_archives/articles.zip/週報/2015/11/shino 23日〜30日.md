---
title: "shino 23日〜30日"
category: 週報/2015/11
tags: 
created_at: 2015-11-30 16:17:46 +0900
updated_at: 2015-11-30 17:20:50 +0900
published: true
---

先週: [#270:  週報/2015/11/shino 13~23日](/posts/270) 

# 今週の作業内容
<!--
## hoge
foo
-->
## このSQL，Railsでどうやってデータ引っ張ってくるの問題
``` SQL
SELECT app_id, info_os_name, MAX(info_sdk)
FROM hogehoge
WHERE info_os_name LIKE '_%' AND info_sdk LIKE '_%'
GROUP BY app_id, info_os_name
ORDER BY app_id DESC
LIMIT 10;
```

``` seed_from_tajima_sp_feature_shino
AppInfo.create([
  {
    app_id: 1,
    info_os_name: "iOS",
    info_sdk: "1.0.2"
  },
  {
    app_id: 1,
    info_os_name: "Android",
    info_sdk: "1.2.0"
  },
  {
    app_id: 1,
    info_os_name: "iOS",
    info_sdk: "1.0.3"
  },
  {
    app_id: 2,
    info_os_name: "Android",
    info_sdk: "4.4.2"
  },
  {
    app_id: 2,
    info_os_name: "iOS",
    info_sdk: "5.0.0"
  },
  {
    app_id: 3,
    info_os_name: "Android",
    info_sdk: "6.0.0"
  },
  {
    app_id: 4,
    info_os_name: "Android",
    info_sdk: "6.0.0"
  },
  {
    app_id: 4,
    info_os_name: "Android",
    info_sdk: "5.1.0"
  },
  {
    app_id: 4,
    info_os_name: "Android",
    info_sdk: "4.4.2"
  },
])

```

app_idは同じなんだけど
os名はAndroidとiOSでくることがある．
その中でもAndroid, iOS それぞれのsdkのバージョンを取得したい．

理想の形は
```
1: Android -> 1.2.3
1: iOS -> 2.1.3
2: Android -> 1.2.4
3: iOS -> 1.2.5
...
```
こんな感じで引っ張りたい
（上記のseedから引っ張ってきたデータではないので誤解をしないように）

Slack の Ruby on Rails channel に投げました．

<img width="703" alt="スクリーンショット 2015-11-30 15.41.46.png (154.7 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/30/5956/ca0c6641-d2d5-429e-9a05-727f43c50f5f.png">

## @shino と @elzup 解答
``` answer1.rb
Hogehoge
.select(:appid, :info_s_name, 'MAX(info_sdk)')
.where("info_os_name LIKE '_%' AND info_sdk LIKE '_%'")
.group('app_id, info_os_name')
.order('app_id DESC')
.limit(10)
```
これだとMAX(info_sdk)の箇所がとれない．

## @tajima の解答
``` answer_tajima.rb
AppInfo
.group(:app_id, :info_os_name)
.maximum(:info_sdk)

(0.3ms)  SELECT MAX("app_infos"."info_sdk") AS maximum_info_sdk, app_id AS app_id, info_os_name AS info_os_name 
FROM "app_infos" 
GROUP BY "app_infos"."app_id", "app_infos"."info_os_name"

=> {[1, "iOS"]=>"1.2.0", [2, "Android"]=>"5.0.0", [3, "Android"]=>"6.0.0", [4, "Android"]=>"6.0.0"}
```
これだとKey が 配列．これでもできなくなはい！
（ごめんなさい @tajima )
でもこれで目的は達成できます！

## 最終版
``` last_answer.rb
HogeModel
  .group(:app_id, :info_os_name)
  .where.not(info_os_name: ‘’)
  .order(:app_id)
  .pluck(:app_id, :info_os_name, “max(info_sdk)”)
```
1. まずシンボルが使える
2. .where.not()って言う使い方
3. 最後にpluck

pluckはSQLで叩いて取れた値を全て配列で返してくれるやつ（要出典）

## なぜselect()関数だと取れないの
MAX() で返ってくるデータヘッダがないからスルーされてしまうということ（要出典）

| app_id | info_os_name | MAX(info_sdk)|
| ------------ | ------------- | ------------- |
| 1 | Android |1.2.3 |

このMAX(info_sdk)がスルーされてしまう（要出典）

## ということでpluckはいい子
pluck関数は高速とのことです（要出典）


# 知見
またひとつRailsと仲良くなった

# 発生した問題
### 時間がない②
研究ってなんだっけ状態に陥っています．
でも作るの楽しいからやめられないんだよなあ

# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```
## :fire: ShelterUniversity開発
北千住チェックラリーアプリはShelterUniversityという名前になりました．
@naoya と深夜に命名
↓にリポジトリだけ作った
http://gitlab.cps.im.dendai.ac.jp/cps/shelter-university

## 所感

目黒のおいしいとんかつ屋にいった ( mens × 3 )
[とんき](http://tabelog.com/tokyo/A1316/A131601/13002040/)ってお店
キャベツ，🍚おかわり自由
![2015-11-28 18.32.33.jpg (1.5 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/30/5956/2a6bdc41-d9fa-42d6-a3cd-3db02705f44d.jpg)

大崎のいい感じのイルミネーションをみた（ mens × 3 )

![2015-11-28 19.46.04.jpg (1.2 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/30/5956/27558e3e-53d7-4771-8377-6c8a76298bfd.jpg)

<!-- 週報 template v1.0 -->
