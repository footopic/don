---
title: "munisystem 23日"
category: 週報/2015/11
tags: 
created_at: 2015-11-23 15:25:32 +0900
updated_at: 2015-11-23 15:53:40 +0900
published: true
---

先週: [#251:  週報/2015/11/munisystem 16日](/posts/251)  

# 今週の作業内容
<!--
## hoge
foo
-->
## 神奈川
雑に断った。
時間が空いたのでもっと有意義なことをしましょう。

## 社
ansible環境下にいるアプリケーションをchef環境下に移行するお仕事をした。
readmeに動作環境や実行方法をちゃんと書いておこうと思った。(小並感)

# 知見
<!--
* hoge
* fuga
-->
## gitlabのバックアップあれこれ
gitlabのバックアップは`gitlab-rake`コマンドで行うことができる。
SSH鍵以外はほぼほぼバックアップされている。(要確認)
注意しなければならないことは、gitlabのバージョンが一致していないとリストアできない点。
ubuntu serverなら、
`apt-get install gitlab=[version]`
でインストールバージョンを指定できる。
ちなみにリポジトリに登録されているパッケージのバージョンは
`apt-cache showpkg gitlab`
で確認できる。

**注意点**
aptのリポジトリに登録されているgitlabのバージョンは現行で7.0.x~8.1.x
つまりgitlabのアップデートサボってるとリストアできなくなるから定期的にしようね。


- バックアップ  
`gitlab-rake gitlab:backup:create` (/var/opt/gitlab/backups/[timestamp]_gitlab_backup.tar)
- リストア  
`gitlab-rake gitlab:backup:restore` (/var/opt/gitlab/backups/ 以下の一番新しいバックアップをリストアする)

# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```
-  輪行

# 所感
ORFめっちゃすごい。
リアなんたらプロジェクトに金使ってる弊学とは大違いだった。


<!-- 週報 template v1.0 -->
