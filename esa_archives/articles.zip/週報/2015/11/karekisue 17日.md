---
title: "karekisue 17日"
category: 週報/2015/11
tags: 
created_at: 2015-11-17 23:03:19 +0900
updated_at: 2015-11-20 10:39:51 +0900
published: true
---

<!-- 先週へのリンク入れて！ -->
先週: [#157:  週報/2015/10/karekisue 28日](/posts/157) 
(隔週作家なので)ないです

# 今週の作業内容
| タスク | 期限 |
| ----|----|
|SFCからNTTに渡すデータの精査・打ち込み| 今週中！！ |
|ET/IoTテクノロジーhttp://www.jasa.or.jp/expo/  |  水木金，みんなで行こう！@横浜|
|ORF2015 http://orf.sfc.keio.ac.jp/2015/  |  金土です@六本木|


<!--
## hoge
foo
-->

# 知見
<!--
* hoge
* fuga
-->
    慶応SFCで5時間ぼっちで作業した，千住キャンパスより近い．
    キャンパスの女子濃度高くて窒息しそう．皆さん優しかった，気を使わせてしまっていた気がする．
    週１で出向マジなんですか(やることない)

- うたわれるもの 偽りの仮面
    - ネコネ可愛いよネコネ
    - クオンちゃん…うっ
    
<!--
![gomennnasaidesu.jpg (100.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/1a3d39b1-7da6-491c-97ea-6414a260bc86.jpg)
-->


<img  src= "https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/1a3d39b1-7da6-491c-97ea-6414a260bc86.jpg"alt="ネコネ金" title =死因なのです width="480" height="272" />

- デレステで違法課金に成功した
    - やったぜ

<!--
![違法課金.png (450.2 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/40758a38-5661-47a0-8419-edf4b1c700cb.png)
-->

<img  src= "https://img.esa.io/uploads/production/attachments/2152/2015/11/16/5958/40758a38-5661-47a0-8419-edf4b1c700cb.png"alt="違法課金" title =違法課金 width="180" height="320" />

# 発生した問題
<!--
## hoge
foo
-->
- usbスピーカでサウンド出力出来ないんですがchrome，なんで…どうして…
- タイムカプセルのマウントが出来ない
@arch linux

# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```

# 所感
年の瀬って感じでそろそろ鍋やりたい，@shinoっち…すきやき…



<!-- 週報 template v1.0 -->
