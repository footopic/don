---
title: "hyuga 22日"
category: 週報/2015/11
tags: 
created_at: 2015-11-23 04:00:00 +0900
updated_at: 2015-11-23 14:22:32 +0900
published: true
---

<!-- 先週へのリンク入れて！ -->
先週: [#233:  週報/2015/11/hyuga 15日](/posts/233) 

# 今週の作業内容
##卒論
* 4枚の論文を薄めてとりあえず32枚になった

## ORF
* コーヒー飲んだだけ

## スクフェス
* 今まで避けてきたスコアマッチに手を出す
* 海未ちゃんほしい

# 知見
* 失点しないだけじゃ上には行けない

# 発生した問題
##デレステ
* パッションじゃモチベ上がらない

# 来週の作業予定
## :fire: 卒論
* 文章見直す

## :palm_tree: Swiftの勉強
* 「Hacking With Swift」を英語読む練習兼ねながら進めていく

# 今週のトロフィー
![プラチナ](http://psnprofiles.com/lib/img/layout/40-platinum.png) × 00
![ゴールド](http://psnprofiles.com/lib/img/layout/40-gold.png) × 02
![シルバー](http://psnprofiles.com/lib/img/layout/40-silver.png) × 06
![ブロンズ](http://psnprofiles.com/lib/img/layout/40-bronze.png) × 35

# 所感
FC東京がチャンピオンシップ出場逃したから何もやる気が出ない
卒論先に書いておいてよかった
