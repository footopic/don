---
title: "hiwatashi 30日"
category: 週報/2015/11
tags: 
created_at: 2015-11-30 16:44:32 +0900
updated_at: 2015-11-30 17:22:58 +0900
published: true
---

先週: #/hiwatashi

# 今週の作業内容
## unity
チュートリアル終わり
##OpenFrameworks
ネットワーク関係のライブラリ勉強中
##FateGo
イベントポイント30万

##unityプロジェクト
アイディア考えた
# 知見
* fatego はやっぱりクソゲー
* 事業の展開の仕方としては勉強になる

# 発生した問題
## unityがちょこちょこ固まる…
そろそろＰＣの買い替え時なのかも？

# 来週の作業予定
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: unityの勉強引き続き
イベント（10日まで）
OFの勉強（ネトプロにむけて）

``` 優先: 🔥 後回し:  🌴```

# 所感


<!-- 週報 template v1.0 -->
