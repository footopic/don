---
title: "tajima 23日"
category: 週報/2015/11
tags: 
created_at: 2015-11-23 13:23:10 +0900
updated_at: 2015-11-23 15:39:46 +0900
published: true
---

最近週報が時間通りにかけません

先週: [#228:  週報/2015/11/tajima 13日](/posts/228) 

# 今週の作業内容

## 工学院のphp環境用box作った(Vagrant)
残念ながらVagrantfileでなくboxです（白目）
あとapache httpdが自動で起動しません。やはりVagrantfileで作るべきだった…
CentOS（Redhat系）のrepoの追加よくわからないしめんどくさい
boxは重いのでどこにも上げてません。NASあたりに入れるか迷ってます保留
（たぶんもういらないっしょ）

## 内定式行ってきた
内定先でバイトもしてるんですが夏からずっと行ってないんで内定消えてるんじゃないかと思ってた（本気で）
行く前は胃がキリキリしたけど行ってみると楽しかった
研究室みたいにvimとかemacsのSlackチャンネルがあるらしい
なんとかやっていけそうです
ブリ美味しかった

ﾍｲｼｬｧのブログです http://techracho.bpsinc.jp/
たまにRailsのこと調べてると引っかかります（ドヤ感

# 知見
## Vagrantで起動時に共有フォルダを使うデーモンはコケる
らしいです。これは`/etc/init.d`などのVM側の仕組みを使う場合。
Vagrantfileで毎回デーモンを立ち上げるようにするか、共有フォルダを変更するようにしてやれば問題ない模様。
フベンかよと思ったけどそもそもVagrantfileだけですべて完結するようにすべきだった


## phoenix_ectoのmodel生成に関して
愚痴りたいので所感に回す

## vimのkeywordprg
Vimは標準でNormalモードで`K`を押すとmanを表示してくれます
これをプログラミング言語に合わせて変更するとベンリなんですが、ﾌﾟﾗｷﾞﾝが変更してくれたりするのであまり考えてませんでした。
自分で変更する場合、
```Rubyのバッファの場合
setlocal keywordprg=ri
```
とかすればいいようです（riはRubyのドキュメント参照ツール）
省略した場合kpと表記します（ドヤ感


# 発生した問題
## 修論APIサーバ完成してない:anger::anger: 
（間に合うのか）もうこれわかんねえな
## ORF行ってない
金曜日のミーティングを寝過ごしてしまうほど寝てしまったのが全て
悔い改めたい

# 来週の作業予定
:fire::fire::fire::fire::fire::fire::fire:
:fire: **修論APIサーバ** :fire:
:fire::fire::fire::fire::fire::fire::fire:


![i320.jpg (23.6 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/6555/bf254691-f1eb-4a5b-84fc-8d49af745909.jpg)


# 所感

## phoenix_ectoのmodel生成に関して
Railsのコマンドでモデル生成する場合、
```shell
./bin/rails g model User name:string email:string 
./bin/rails g model Post title:string body:text belongs_to:user
```
すると思うんですが、これをPhoenixでやろうとすると
```shell
mix phoenix.gen.model User users namt:string email:string
mix phoenix.gen.model Post posts title:string body:text
user:references:users
```
こうなります
全部明示した(referencesのとこ）んだからやってくれてもいいじゃんと思ったんですがやってくれませんでした。
というか公式で書いてること違って日本語で書かれてるブログのほうが正しいこと書いてありました。

ｱｰﾘｰｱﾀﾞﾌﾟﾀは神:angel: 

確認したらRailsでも結構めんどくさい記述しなければいけなかったので僕がただの雑魚だったわけですね

## DBに関する名前ってむずくないすか
DBの勉強なんもしてなかったので使える規則的なのがあるなら教えて欲しいです

* posted_by_id
* user_id

どっちがいいんでしょうか。目的はPostしたUserのidを引っ張ってくることなんですが、それはプログラムのメソッド名でやる話なのかDBのカラムまで？？？？
というかposted_byって正しいのかよとか？？？？？？？？
## デレステ
白封筒ばっかだよぉ
今回イベントはもうお漏らししすぎて無理っぽいですが少し割ってｶﾞﾝﾊﾞﾘﾏｽ
 
## デレマス
![Selection_005.png (253.3 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/6555/191d8860-8625-4157-9161-6efdc7fd6373.png)

<!-- 週報 template v1.0 -->
