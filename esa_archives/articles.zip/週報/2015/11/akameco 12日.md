---
title: "akameco 12日"
category: 週報/2015/11
tags: 
created_at: 2015-11-13 00:10:35 +0900
updated_at: 2015-11-16 16:12:56 +0900
published: true
---

# 週報

## 東京Node学園祭2015
1000円払ってこれ行ってた。
[東京Node学園祭2015](http://nodefest.jp/2015/)
資料とか上がってるのでnode興味ある人はググればいいと思う。

お昼は1000円払ってこれ食ってた。

![DSC_0383.JPG (1.3 MB, orientation fixed)](https://img.esa.io/uploads/production/attachments/2152/2015/11/12/6061/132dd1b3-7b05-480a-9f91-013e3171f9b7.JPG)


## 神奈川大学プロジェクト
androidの知見なくてあまり進んでない。

## zsh
さよならfish
とにかく環境変数の指定の仕方忘れまくってフラストレーション溜まるのでzshに戻した。
zsh、oh-my-zshとかpreztoとか使ってたけど、alias自分で定義したいしoh-my-zshとかいらないプラグインとか邪魔な記述ありすぎるし逆に面倒なので、Antigenでプラグイン管理して使ってる。

## 社
gitのコミットメッセージの先頭決まったフォーマットでやるとよい
fix add change remove upgrade等

## ラボの掃除
今週一番頑張ったのはこれです。
軽く４時間以上掃除した成果です。

![87c331694ad98fdeab1a22c17a0f69d5.jpg (28.0 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/13/6061/05322bb6-97c2-4137-979f-7084fb388ce2.jpg)
