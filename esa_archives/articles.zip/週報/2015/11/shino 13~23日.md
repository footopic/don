---
title: "shino 13~23日"
category: 週報/2015/11
tags: 
created_at: 2015-11-23 11:38:57 +0900
updated_at: 2015-11-24 02:56:29 +0900
published: true
---

先週: https://cps.esa.io/posts/216

# 今週の作業内容
## 2015/11/14 
### 学内駅伝
の予定が，地面が濡れているためドッジボールに変更
### 参加者
* CPS Lab Team  @tajima , @mikekuroe , @kyosky @kinchan 
* shico's亭 @shino , @karekisue ( @ren , @taki )

### ドッジボールの後抽選会!
当たり賞品は
G-shock, PS4,  ipod nano

### 戦利品
ドライヤー @shino 
ワックスuevo @kinchan 
スピーカー @tajima 
体重計 @mikekuroe 
ファイテンのチタンネックレス @karekisue 
でした．

来年も出れる人は出ような〜(\\( ⁰⊖⁰)/)



![](https://slack-files.com/files-tmb/T02TM1NQZ-F0EGLTU2J-50faa1c223/dsc_0317_1024.jpg)
![2015-11-14 12.43.12.jpg (462.5 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/5956/98864ac5-a447-4ab6-8fcf-870789ff1af2.jpg)
![2015-11-14 12.43.08 HDR.jpg (282.7 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/5956/8f55baec-7e9b-433e-bdf5-1977b833b60c.jpg)


## メタップスでインターン（アルバイト）
火曜日と水曜日は，10:00-19:00で西新宿のオフィスです．
先週はRailsでチュートリアルも兼ねてviewを使って実装するって言う割と簡単めなタスクを与えてもらった．
railsだけでなくviewでbootstrapを使っているので中々ﾊﾏﾙﾊﾏﾙ

### Redbull が飲み放題
です



<!--
## hoge
foo
-->

# 知見
### コードを書いてお金をもらうお仕事って悪くない
私服でok , タスクこなせばokっていうスタンスは性に合っているような気がする．

# 発生した問題
### 時間がない
研究ってなんだっけ状態に陥っています．
でも作るの楽しいからやめられないんだよなあ

<!--
## hoge
foo
-->

# 来週の作業予定
<!--
基本優先順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
## :fire: hoge
fooo
-->
``` 優先: 🔥 後回し:  🌴```

## :fire: Railsの勉強するじかんどうしよう
## :fire: :palm_tree:  :fire: チェックラリーアプリどうしよう
## :fire: :palm_tree:  :fire: 防災アプリどうしよう


# 所感
### 東大駒場祭に参加してきた
なんだかcleverそうな人が多かったです

## 伊藤計劃のハーモニーを見てきた
TOHOシネマズ新宿で舞台挨拶みてきた
生みゆきちすごかった〜
![2015-11-14 19.19.37.jpg (1.9 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/23/5956/6ce88b99-7417-4348-a2e9-92af6d8b9942.jpg)

記事
http://www.cinemacafe.net/article/2015/11/15/35670.html


<!-- 週報 template v1.0 -->


