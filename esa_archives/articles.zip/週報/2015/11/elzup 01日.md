---
title: "elzup 01日"
category: 週報/2015/11
tags: 
created_at: 2015-11-02 02:36:16 +0900
updated_at: 2015-11-03 16:11:43 +0900
published: true
---

# 今週の作業内容

## アブソリュートデュオ スイッチ Web ページ
要望に合わせて Webpage の実装をした
<img width="434" alt="Screen Shot 2015-11-01 at 23.50.12.png (125.8 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/01/5955/3d9b0c5b-1063-431c-a26e-2796ad41ad33.png">

## BookRentaler(むにデモ)
要望に合わせて Webpage の実装をした
<img width="1231" alt="Screen Shot 2015-11-01 at 23.57.30.png (112.7 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/01/5955/d50ca80e-6d03-4452-9372-47b6a9e92c75.png">


## 旭祭　LiveCoding
要望に合わせて Webpage の実装をした
<img width="1302" alt="Screen Shot 2015-11-01 at 23.43.58.png (399.4 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/01/5955/93a313d0-1671-4060-b27d-419c5975d76e.png">

## コミットガシャ
ちょっとスタイルもつけた
Rパジャマちえりちゃん出た
<img width="654" alt="Screen Shot 2015-11-02 at 02.22.53.png (1.3 MB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/02/5955/c3e021d3-7d69-4af1-a689-cf69d614f19a.png">


# 知見
* Rails フロント周り


# 発生した問題

![kaikai.jpg (140.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/02/5955/87aebfdb-ba81-4a0b-a162-1b9f829a6976.jpg)


# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: Twitter人流に感情の反映と可視化
* 感情解析APIを使っていろいろ強化する

## python 競プロの勉強

## :palm_tree: TryPoint
旭祭 Livecoding 前半はこれを作っていたんですが
コミュニティ(とりあえず研究室)向けエンターテイメントサービス
https://drive.google.com/open?id=0B_q7EUWlJ6Y4MG9tNkc1MnUxMVE


# 所感
久々にフロントエンドの実装を何回かした
![sakurako.jpg (62.4 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/11/02/5955/86fb244a-6f8d-40c4-8970-9055d38a3616.jpg)

