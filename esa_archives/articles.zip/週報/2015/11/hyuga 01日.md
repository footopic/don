---
title: "hyuga 01日"
category: 週報/2015/11
tags: 
created_at: 2015-11-02 01:44:51 +0900
updated_at: 2015-11-02 01:59:36 +0900
published: true
---

# 今週の作業内容
## 東大ミーティング
* 学会発表の練習

## 旭祭
* オープンキャンパスやアプリコンテストで使ったものを少し修正しただけ

## PS3の容量確保
* アニメを大量に消化したおかげでアメリカ行ってる間も安心

# 知見
*  7ヶ月も前から自分の知らない岩井研のFacebookグループが存在していた

# 発生した問題
## デレステ
###Nation Blue
* 開始が２日遅れたせいで２枚目のSRゲットできず

###LIVE Groove Vocal burst
* MASTER1曲クリアするだけで精一杯なのに3曲連続なんて無理ゲー
* PROだとつまらない

# 来週の作業予定
## :fire: アメリカで学会発表
* 英語できないけど頑張る 

## :palm_tree: デレステ
* MASTERの修行 

# 今週のトロフィー
![プラチナ](http://psnprofiles.com/lib/img/layout/40-platinum.png) × 00
![ゴールド](http://psnprofiles.com/lib/img/layout/40-gold.png) × 02
![シルバー](http://psnprofiles.com/lib/img/layout/40-silver.png) × 01
![ブロンズ](http://psnprofiles.com/lib/img/layout/40-bronze.png) × 02

# 所感
スクフェスのイベント初めてSRゲットするぐらいやったのに終わってしまってEX2曲しかできなくて物足りない

デレステのイベントなんてなかった
