---
title: "shino 12日"
category: 週報/2015/11
tags: 
created_at: 2015-11-12 11:38:45 +0900
updated_at: 2015-11-15 23:20:59 +0900
published: true
---

# 今週の作業内容
## Ruby on Rails Tutorial
[ここ](http://railstutorial.jp/chapters/sign_up?version=4.2#cha-sign_up)
6章まで終わった．12章までなのであと半分
Railsのこと好きになりそう

テスト駆動開発
レッド・グリーンリファクタリング
🍅🌽💻
について学べるのでざっとやるだけでも力になりそうだよ



## Unity
社案件．w/ @shinji 
こんなのとか（ほんとはgifとかでみせたい）
<img width="200" alt="スクリーンショット 2015-11-12 10.51.25.png (129.6 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/12/5956/21e6de97-66a3-4d7d-8ed2-58a2618d5e8f.png">

こんなのとか（ほんとはgifとかでみせたい）
<img width="200" alt="スクリーンショット 2015-11-12 10.51.48.png (181.4 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/12/5956/d2d03c6d-6c67-444f-b6f2-0f89d405d6f5.png">
上半分は開発画面
下半分は実際にスマホでプレイした時の画面

視点を磨くツール（**ゲームではない**）
ユーザーもステージを作れるように開発中です．乞うご期待(?)

[前回見せたもの](https://cps.esa.io/posts/191)よりも
影のギザギザが少なくなった．
使うコンポーネントを変えたら描画量が減ったみたいだ．
Directional Light -> AreaLight が良いみたい

UnityにはPrefabという概念があります．
組み合わせたパーツを部品化する，っていう感じのものです．
自分だけのツールを作ってく感じが結構楽しかったり．
オリジナルのスイッチ作ったり，ワープする床を作ったり．


## 突然の工学院案件（SIP）
w/ @mikekuroe , @elzup , @tajima 

PHPで書いてあるWebアプリをレスポンシブ対応する必要がある．
@mikekuroe にBootstrapを使ってもらうということで業務委託．

LAMPの環境構築は↓
http://weblabo.oscasierra.net/setup-lamp-rhel7/

というわけで自分もPHP環境構築中です．(2015/11/12 現在)

書いてる間に終わった．

<img width="720" alt="スクリーンショット 2015-11-12 11.25.18.png (228.7 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/11/12/5956/75ed9551-5185-48f5-ba1d-07e55eda1194.png">

phpの最新5.6みたいだからちょっと気になるけど．


# 発生した問題
## Vagrantで環境作って192.168.33.10にIP割り振ってアクセスしても表示されない
firewalld の設定を見てみる．ローカル環境ならfirewall切っても大丈夫（なはず）.
ただ単に80ポートをfirewalldが禁止しちゃってるだけなので
それを開けてあげればokok.
っていうハマり方(2回目)
あるあるだから思い出すといいことあるかもよ．

参考文献
http://qiita.com/takuhou/items/1bdd8403a15be7411e20

# 来週の作業予定
## :fire: Rails Tutorial 終わらせる
終わらせる．duty. 11/17までに

## :fire: 工学院のWebアプリを今作った環境で動作確認
動作確認

## :fire: チェックラリー動きます
最近滞っていたのですが，北千住版のチェックラリーアプリ始めますよ．

始めますよ．



# 食生活を振り返る
* Saturday:  @tajima とすき焼き作って食べた at しこっち亭
* Sunday: 高校の同期とバーミヤン
* Monday: [田中商店](http://www.tanaka-shoten.net/)っていう臭いラーメン屋（でもおいしい）
* Tuesday: [つけ麺道](http://ramendb.supleks.jp/s/21633.html) 火曜日は塩ラーメンの日．名店． 接客神対応
* Wednesday: 普通
* Today : セブンコーヒーL と肉まん

ただただラーメンを紹介したかっただけっていう

### よかったらみてみて
学習院で演奏したやつ
https://www.youtube.com/watch?v=Wuittnvf5ss



