---
title: "munisystem 11日"
category: 週報/2015/10
tags: 
created_at: 2015-10-12 11:32:30 +0900
updated_at: 2015-10-14 15:50:35 +0900
published: true
---

# RTX1500もらった
初めてのYAMAHAルーター
シリアルクロスケーブルなんてものを持っていないのでAmazonで以下をポチった
http://goo.gl/zjshml
http://goo.gl/gCyyxF
http://goo.gl/iKBcXf
ルーター自体にsshサーバーが建てられ、設定さえすれば手元のターミナルからアクセスできるしすごい

# Terminatorに戻した
今まで軽量かつ設定が楽って理由でlilytermを使っていたが、iTerm2の水平垂直分割が羨ましくてTerminatorに再度移行した
ターミナルの透過や画像埋め込みもできるので、痛作業環境をつくりたいlinuxユーザーにはおすすめかもしれん
tmux screen byobuで画面分割をすればいい話だったりする

# Baculaを触る
OSSのバックアップツールであるBaculaを社関連で触り始めた
文献が少ないのでつらい
bacula.jpがガバガバでつらい
http://goo.gl/GGZDka

# おは60
全敗

# ポンコツアンドロイド
さよなら50000位

