---
title: "elzup 18日"
category: 週報/2015/10
tags: 
created_at: 2015-10-19 13:58:39 +0900
updated_at: 2015-10-21 13:06:16 +0900
published: true
---

# 今週の作業内容
週報を水曜日に書こうということになったの今週の前半は先週の週報にまとめてしまった
が，やはり日曜日に書くのがいいいと思ったのでそうする

## 残留ログ可視化
下線が残留日
![Screen Shot 2015-10-16 at 19.28.42.png (19.9 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/10/19/5955/b9dd3668-7453-4220-ae82-bbcc415bd618.png)



## mushup awards 申し込んだ
ドミネーターを投稿した


## ミーティング: B3向けLT
* http://slides.com/hirototakahashi/deck-2#/

## commit_gasha 
というWebアプリを作りながら CI と開発フローの勉強をしている
ちなみにこのプロダクトはデレステ卒業も見込める

## ブログ, Qiita
mac Fluid.app でログインが必要なアプリを使う http://qiita.com/elzup/items/7456b26c802b9a4b1b25

# 知見
* git
    * hub コマンドの強化
        * プルリク作成とか
    * tigrc の強化
    * Waffle.io 使い始めた
* CircleCI + Rails での CI の勉強が捗り始めた

## 良記事
* GitHub - 開発フロー研修 @ Wantedly - Qiita http://qiita.com/awakia/items/c571e93e96a1ec28044f
* RailsでいろんなSNSとOAuth連携/ログインする方法 - Qiita http://qiita.com/awakia/items/03dd68dea5f15dc46c15

# 発生した問題
ナイナイナイアガラ
![niagara.jpg (126.3 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/10/19/5955/b32b7332-5b29-4b42-8452-f1f37e58ceb2.jpg)




# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: :fire: OC スプラトゥーン
ラズパイゲーム化を目指して

## Code Festival 予選B に向けて勉強

## :palm_tree: elzup API
rails に保存していく〜


# 所感
今期見たいアニメはガンダムとゆるゆりと終物語で決まりつつある
Gitlab cps/manual の Issue が使われなくなりつつある
