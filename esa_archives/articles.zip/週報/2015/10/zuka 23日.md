---
title: "zuka 23日"
category: 週報/2015/10
tags: 
created_at: 2015-10-23 13:49:46 +0900
updated_at: 2015-10-24 11:42:25 +0900
published: true
---

# 今週の作業内容
##TAKAYAのRFID
Jsonの受け取り方法をリストから単一受け取りに修正
スクリプト全体のメソッド化などのリファクタリング
## アニメ消化
ゆるゆり1~3話
ごちうさ1~2話
デス・パレード1話
##発表学会決定
http://www.interaction-ipsj.org/2016/submissions
上記

# 知見
* C#(Unity)だとListは”参照渡し”になるので"="で要素受け渡しはしない
* ゆるゆりはelzupが居るときに見る



# 発生した問題
## TAKAYAのRFID
Listを=で受け渡ししたうえで参照元の要素を変えたら参照先も要素が変更されていてバグった



# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: 学会用の論文作成
http://www.interaction-ipsj.org/2016/submissions
上記の学会に提出予定
章立ては完了しているので箇条書きで書くことをまとめてます。

## :palm_tree: TAKAYAのRFID
スクリプトのリファクタリング
Androidでのビルド

