---
title: "tajima 15日"
category: 週報/2015/10
tags: 
created_at: 2015-10-15 04:52:48 +0900
updated_at: 2015-10-29 03:38:05 +0900
published: true
---

# 今週の作業内容

## ElixirのGetting Startedしてます
なんか本家の英語読みながら頑張ってたら日本語あって力抜けました
[本家英語](http://elixir-lang.org/) ／ [有志？日本語](http://elixir-ja.sena-net.works/)
みなさんも気が向いたらどうぞ

## 論文書き手伝い
ました。kpもしぼめう氏もお疲れ様でした(ヽ´ω`)

## RISCONのアレ
グラフツール手伝ったりしました
がんばれ:heart: がんばれ:heart:
 
## FBやらTwitterで流れて来たもの眺めました
データの第三者提供と匿名化、あとは地理院タイルについて
URLぱっと出てこないんですが聞かれたら貼ります

# 知見
###やっぱりちゃんと関数型プログラミングわかってないとElixirつらい
別に特段早いわけじゃないし修論で書いたソフトが大規模に使われることなんてほぼないだろうからRailsでちゃっちゃとやりたい（えるさっぷ氏のに手を加えればはやそう）気持ちとせっかく勉強してるんだからElixir使いたいという気持ちの板挟み
ただ、日本語リソース読んでたらなるほど感が強かったのでやっぱりElixir使いそうです

### 案外みんなAndroidのネットワーク通信に関してわかってない感があった
僕もあんまり得意ではないんですが、`IntentService`と`AsyncTask`はネットワーク通信を行う時に使用します。ただ、`IntentService`から`AsyncTask`をexecuteするとほとんどの場合でエラー吐きます（吐かなくても運が良いだけ）ので、`Activity`もしくは`Service`から`AsyncTask`をexecuteするか、`IntentService`からリクエストを送るかのどちらかにしましょう。
ちなみに`Service`は便利なんですが重い処理させるとUIスレッドの動作を妨げます。

さらに言うならAndroidアプリ開発はライブラリ活用したほうが良いです。
Volleyや[okhttp](https://github.com/square/okhttp)は有名どころです。
イベントの通知をあのクラスに…！なんて場合は[EventBus](https://github.com/greenrobot/EventBus)がいいでしょう

# 発生した問題
## セキュスペ勉強してない
爆死してきます



# 来週の作業予定

        優先順位
        基本高い順に書く
        必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)

- :fire: **修論タイトル決め**（いそぎ（すごく））
- :fire: 修論サーバソフトデータ構造定義
- :palm_tree: サーバ仮実装
- :palm_tree:  BPS
- :palm_tree: Androidで修論クライアント実装リファクタリング
- :palm_tree: データの匿名化について調査
- :palm_tree: Docker Server（立ててmattermost試します）
- :palm_tree: meshi
- :turtle: そろそろ14Fで遊ばせてるEdisonとラズパイをうんぬん

# 所感
この項はどっかにドキュメントとして吐き出すかも
## :books: おすすめ技術書／ドキュメント :page_with_curl: 
 - :book: [ハイパフォーマンス ブラウザネットワーキング](http://www.oreilly.co.jp/books/9784873116761/) （ラボにある）
 - :book: [Effective Java (Amazon)](http://www.amazon.co.jp/EFFECTIVE-JAVA-%E7%AC%AC2%E7%89%88-Java-Series/dp/4621066056) （ラボにあるのは第1版かも）
 - :book: [リーダブルコード](http://www.oreilly.co.jp/books/9784873115658/)（ラボにある）
 - :book: [Linux 実践入門](https://gihyo.jp/dp/ebook/2013/978-4-7741-5898-3)（ラボにある。Linux初めて触る人むけ）
 - :page_with_curl: [mixi -AndroidTraining](https://github.com/mixi-inc/AndroidTraining) 

## 技術系 もしくは読みたい本とか
- :warning:  プロジェクト絡んでてコケるとまずいもの（CityWalkersのAPIとか）は勉強がてらテスト書きたいっすね
- :book: 積んでる本がたくさんあるぅ……

## 後輩へ
### 先生のこと
- 先生はラボで対面もしくはガンガンFBで質問しないと返答帰ってこないです。ただし質問は必ず明確にしましょう
- 急ぎなら優先度高めてもらうために急ぎであること（期日）も伝えたほうがいいっす。反応なかったら電話かけましょう
- RISCONに出してるプロジェクト見て改めて思いましたが、先生が予定繰りするとマージン0になってどこかでコケたらデスマ確定になるので出来れば自分でハンドリングする（もしくは先輩に頼む）のが良いと思います

### 技術のこと
- 自分がわからない技術があるのはごく当たり前のことです。わからないから人に聞くのも悪いことではありません。ただ、人に聞く前に下調べはしましょう
- 何かを教えてもらったら何かを教えましょう
