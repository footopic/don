---
title: "hyuga 25日"
category: 週報/2015/10
tags: 
created_at: 2015-10-26 03:47:32 +0900
updated_at: 2015-10-29 03:35:14 +0900
published: true
---

# 今週の作業内容
## メトロアプリ
* エラーの原因が特定できなくて心が折れたので細かい修正のみ

## 東大ミーティング
* 学会発表の準備

# 知見
*  プレゼンのコツ

# 発生した問題
## 英語
* 読めない
* 書けない
*  話せない

# 来週の作業予定
```
優先順位
基本高い順に書く
必須最優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: 学会発表の準備
* とにかく練習

## :palm_tree: PS3の容量確保
* アメリカ行くまでに一週間分録画できるようにする

# 今週のトロフィー
![プラチナ](http://psnprofiles.com/lib/img/layout/40-platinum.png) × 00
![ゴールド](http://psnprofiles.com/lib/img/layout/40-gold.png) × 06
![シルバー](http://psnprofiles.com/lib/img/layout/40-silver.png) × 09
![ブロンズ](http://psnprofiles.com/lib/img/layout/40-bronze.png) × 03

# 所感
デレステイベントなんとかSR蘭子GET
でも判定が意味不明すぎてスクフェスのイベントやってる方が楽しい
SSR出ない不具合早く直して
