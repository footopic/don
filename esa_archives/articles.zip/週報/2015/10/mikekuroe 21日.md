---
title: "mikekuroe 21日"
category: 週報/2015/10
tags: 
created_at: 2015-10-21 14:03:34 +0900
updated_at: 2015-10-23 04:24:04 +0900
published: true
---

# 今週の作業内容
## 基本情報
午後で死んだ
## Javaの復習
![41gBjvodQFL._BO2,204,203,200_PIsitb-sticker-v3-big,TopRight,0,-55_SX324_SY324_PIkin4,BottomRight,1,22_AA346_SH20_OU09_.jpg (18.0 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/10/21/6202/04540ec2-20fb-4c70-925e-40076da0c248.jpg)
ひさびさに取り出して読書に使ってますが、カプセル化が苦手な僕にはちょうどいい資料になりそうです
#絵
##<img width="164.57142857142858" alt="Intuos初魔法陣efect.png (372.7 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/10/21/6202/efa53728-077f-4f97-a009-f489bbc7f773.png">
ピクシブで活動はじめました
誰かかわいい女の子の書き方教えてください
#駅伝
##中学校の長距離走以来のイベント参加ですが頑張ります

# 知見
* 僕には学がない
* 複数のクラスを利用して拡張クラスを作る場合
    * スーパークラスを継承したスーパークラスを継承すればいいらしい
    * もちろん拡張性のために汎用クラスを用いるのほうが良い
* 大学4年にもなって中二病とかはずかしくないの？
* はずかしいです


#自白
今週のミーティングは手術あるのでいけません

# 所感
手術と三回正しく打てた人から先生とご飯食べてよいこととします

