---
title: "hyuga 18日"
category: 週報/2015/10
tags: 
created_at: 2015-10-19 11:38:56 +0900
updated_at: 2015-10-21 01:54:10 +0900
published: true
---

# 今週の作業内容
## Swiftの勉強
* 動けばいいというクソプログラムをなんとかしたい
* まずはSwiftを基礎から勉強し直し
* WWDCの動画を見ることで英語に慣れる訓練も同時に

## 東大ミーティング
* 「プログラムは育てるもの」
* アプリコンテストの振り返り
* 英語でのプレゼン資料の作り方

# 知見
* 今までスルーしてたenum, struct, closureなどの使い方

# 発生した問題
## デレステ
SSRが出ない

# 来週の作業予定
```
優先順位
基本高い順に書く
必須最優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: 学会発表の準備
日本語の発表すらうまくできたことない＋英語できない＝やばい

## :palm_tree: メトロアプリ
今後の改良に向けてリファクタリング

# 今週のトロフィー
![プラチナ](http://psnprofiles.com/lib/img/layout/40-platinum.png) × 00
![ゴールド](http://psnprofiles.com/lib/img/layout/40-gold.png) × 00
![シルバー](http://psnprofiles.com/lib/img/layout/40-silver.png) × 01
![ブロンズ](http://psnprofiles.com/lib/img/layout/40-bronze.png) × 10

# 所感
はじめはito先生の冗談だと思っていた英語論文や海外での発表。
ESTAの申請まで済ませたら本当にアメリカに行くんだなと実感してきた。
英語全くできないやばいやばいやばいやばいやばい
