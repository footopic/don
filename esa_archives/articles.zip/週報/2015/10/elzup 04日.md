---
title: "elzup 04日"
category: 週報/2015/10
tags: 
created_at: 2015-09-30 10:36:50 +0900
updated_at: 2015-10-05 13:42:40 +0900
published: true
---

# 今週の作業内容
## アーバンデータチャレンジ LT
5分発表してきました
* 資料作成
* エリアストレスAPIの作成
* http://aigid.jp/?p=1248
![Screen Shot 2015-09-30 at 10.51.21.png (2.3 MB)](https://img.esa.io/uploads/production/attachments/2152/2015/09/30/5955/107b2d37-e8fb-4b4a-b2f3-d30706f0a705.png)


## cityWalkersMeterAPI の更新
* /logs/udpate/single の追加
* リファクタ

## CPS Systems 構想発表
[スライド](http://slides.com/hirototakahashi/cps-system#/)


## cps.tdu.black の復活
* 9月で共用サーバの期限が切れたので
* 別のレンタル vps に nginx で設置した
* リファクタリングした
* http://cps.tdu.black

## vimperator 更新作業
環境構築
* googleselector をちょっと強くした
* https://github.com/vimpr/vimperator-plugins/commits?author=elzzup

# 知見
* CI 入門
* Git flow
* hook

# 発生した問題
## あんずのうた Master がクリアできない




# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```

## :palm_tree: goodname作成
最近適当に遊びで作り始めた Twitter 連携サービス


## :palm_tree: cps 版 esa の立ち上げ
* rails?
* サーバーサイドはAPIだけ作ってフロントエンドに注力(赤芽案)

# 所感
デレステイベント無事2枚回収しました
以前に比べてかなりこまめなタスク管理を始められているので続けていきたい
TED とか見始めてる

