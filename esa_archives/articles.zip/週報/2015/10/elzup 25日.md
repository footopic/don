---
title: "elzup 25日"
category: 週報/2015/10
tags: 
created_at: 2015-10-19 16:24:37 +0900
updated_at: 2015-10-26 22:40:36 +0900
published: true
---

# 今週の作業内容
## commit_gasha 
動作はだいたい完成した

<img width="609" alt="Screen Shot 2015-10-25 at 23.31.33.png (828.3 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/10/25/5955/3aaca478-d938-44c1-8179-cd5488283151.png">


## Codefestival 予選B
もしかしたら予選通過できそう！

<img width="962" alt="Screen Shot 2015-10-25 at 23.02.21.png (81.4 kB)" src="https://img.esa.io/uploads/production/attachments/2152/2015/10/25/5955/ce45b968-9bac-4139-928f-a9ce001e8508.png">

## 無料ピザ乞食
美味しかった
午後の体調が優れなかった

* ミーティング http://slides.com/hirototakahashi/deck-3#/



# 知見
* Waffle.io と issue 開発に慣れてきた
* セブン > ローソン > デイリーヤマザキ (かりんとうの個体がデカイ順)

## おすすめ記事
* Ruby - 使えるRSpec入門・その1「RSpecの基本的な構文や便利な機能を理解する」 - Qiita http://qiita.com/jnchito/items/42193d066bd61c740612



# 発生した問題
![d31199ff.jpg (117.1 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/10/25/5955/73b9a1ad-a957-4680-bf3f-1374e541c305.jpg)



# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: 旭祭準備
ラズパイにザップトゥーン移植

## MISSION アプリを作る
:secret: 

# 所感
B3 生が入り浸り始めて

