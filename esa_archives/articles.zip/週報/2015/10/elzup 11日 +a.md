---
title: "elzup 11日 +a"
category: 週報/2015/10
tags: 
created_at: 2015-10-08 03:36:38 +0900
updated_at: 2015-10-29 03:38:39 +0900
published: true
---

# 今週の作業内容
## blacktimer.elzup.com
* かなりキレイなプロジェクト管理体制が出来た

## cityWalkersMeterAPI 更新
* view の更新
    * ページングとか
* サポートするリクエストの例外を追加

## ミーティングミーティング
* これからのミーティングをどうするかについて

## Minecraft サーバー起動

## Gitlab, Slack に B4, M1, M2 招待

## ブログ, Qiita
gitignore_global に書くべきものの判断 - Qiita http://qiita.com/elzup/items/4c92a2abdab56db3fb4e


# 知見
* プロジェクトの管理
    * npm, bower,  gulp, build部分


# 発生した問題



# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```
## :fire: zuptoon
* ゲームフレームワーク化
* ラズパイに移植
* OC を目標


## meshi の作成
* プロジェクト立ち上げ
* 30分ミーティングの実施

## commit_gasha[WIP]
* commit 数でガシャが回せる

## :palm_tree: AndroidApp ログインゲーム 作成


# 所感
B4生が入ってきてラボの色んな面をしっかりしないと行けないと思った


