---
title: "kyosky 29日"
category: 週報/2015/10
tags: 
created_at: 2015-10-29 01:10:35 +0900
updated_at: 2015-10-30 00:47:45 +0900
published: true
---

# 今週の作業内容
## thinkpad
・デュアルブート仮想環境などの構築
・.vimrcの編集
・gitの導入
・AutoHotKey
## 論文調査
・ユーザーインターフェイスについて



# 知見
* 電大のwindowsはアップグレード版ではない
* .vimrcは凝りだすと時間が飛ぶ
* AutoHotKey便利



# 発生した問題
## gitむずい
むずい



# 来週の作業予定
```
論文調査
```
## :fire: 電大駅伝
トレーニングしましょう

# 所感
今週は少しだらけました。
