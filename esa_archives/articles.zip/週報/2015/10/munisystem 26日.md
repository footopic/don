---
title: "munisystem 26日"
category: 週報/2015/10
tags: 
created_at: 2015-10-26 11:38:45 +0900
updated_at: 2015-10-29 03:35:16 +0900
published: true
---

# 作業内容
##  Itamae
自分の中でベストプラクティスが確立した。
暇があったらWiki的なものに書き起こしておく。

##  Bacula
linux、windows向けバックアップツールであるBaculaが最低限使えるくらいの知識を得た。
参考になる記事がものすっっっっっっっごく少ないから後でQiitaに記事をぶん投げておく。

## Node.js
展示用の作品につかうapiを作った。(Node.js,Express,MySQL)
Node.jsのアプリケーションフレームワークであるExpressを使うとクッソ簡単にapiが作れる、すごい。

参考文献
- https://gist.github.com/iksose/9401758

## 開発環境
LXC(仮想環境) + Itamae(プロビジョニングツール) + scp(ファイル転送)を使った開発がものすごく良い。
手元の環境を汚さないのはもちろんコンテナの設定をプロビジョニングツールを用いているので、本番環境のデプロイが楽になる。

## Dアニメストア
***ファッキンSilverlight***
Windows10でcode6030連発する。
モニターはすべてHDCP対応してるし、HDMIとDVIでしか接続してない。
ちなみにAmazonプライムビデオではエラー吐かない。

## BeatmaniaIIDX INFINITAS
あたった。
遅延ひどい。

## 昼からピザとビール
うまい

## からの夜おでん
量がわからない

# 所感
濃厚な一週間だった気がする。

