---
title: "sue 21日"
category: 週報/2015/10
tags: 
created_at: 2015-10-21 01:15:41 +0900
updated_at: 2015-10-22 01:55:26 +0900
published: true
---

# 何かあったかな(10/14-10/21)
##お賃金ほしいの

###買ったもの
* [強化ガラス ( 硬度 9H ) 型 液晶保護 フィルム(前面)](http://www.amazon.co.jp/dp/B00WSKB2DO)  
*  [強化ガラス ( 硬度 9H ) 型 液晶保護 フィルム(背面)](http://www.amazon.co.jp/dp/B00WSKB2EI)  
*  [アルミニウムバンパー](http://www.amazon.co.jp/dp/B00U1A3KEM)  
    もう壊さない
* [ドリンクリップ](http://www.amazon.co.jp/dp/B006Y2L73M)  
机にタンブラーをセット出来る，つよい みんなも買おう

###欲しいもの
ips液晶とかですね

# 知見
xcapeでキーバインドを起動時から固定したかったけど，.xprofileでもxinitrcでもsystemdでもダメだった(丸投げ)

# 発生した問題

# 来週・今週の作業予定
## :fire: SOX鯖やるやるやるから

# これから
後期の学会発表については上のをごちゃごちゃ使って生活物価の測定とかやろうと思います．
あとはM1でグループで何かやろうかって話も出てるのでそれも．
