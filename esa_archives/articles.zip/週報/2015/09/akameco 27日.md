---
title: "akameco 27日"
category: 週報/2015/09
tags: 
created_at: 2015-09-27 18:06:43 +0900
updated_at: 2015-09-27 18:28:09 +0900
published: true
---

先週の土日に発生した16時から35時勤務で圧倒的成長をした。

# 今週の作業内容

## 鯖の構築
さくらVPSで標準でインストール可能なcentOSがぶっちゃけ好きではないのでubuntuをインストールした。
ssh、iptables、docker、nginxはitamaeで自動化した

- [Home · itamae-kitchen/itamae Wiki](https://github.com/itamae-kitchen/itamae/wiki)

itamaeは軽量なchefという感じで環境構築のための環境構築に時間をかけずに済むので、小規模の構築なら楽だと思う。

## drone.ioでデプロイの自動化
デプロイをgithubにpush→自動デプロイを実現したかったので、drone.ioを利用した。他にもtravis.ciやcircle ciなどあるが、sshを利用したかったのでwebのUIから設定でき、ある程度セキュリティを担保できそうという理由。ただ、標準で用意されてる環境がnodeのバージョンが低かったりと微妙なので、代替の手段にはすぐに移れるようにしたい。

## docker-composeでアプリケーションの構築
docker-composeを使うことで適当にクローンして`docker-compose up`するとどんな環境でもアプリケーションが動くという安心があってよい。研究室希望APIはこれで動かしてる。ただ、実際に動かすとなるとnginxなどのホストOS側にも手動で設定を書かねばならず少し面倒。

- [Docker Compose](https://docs.docker.com/compose/install/)

## gitlab v8
gitlabの最新版のインストールに消耗した。

## 日本語ドメイン

悪いこと言わないからやめとけ。

![tumblr_nszzxik4cx1qa94xto1_500.gif (929.9 kB)](https://img.esa.io/uploads/production/attachments/2152/2015/09/27/6061/5697aa5c-e860-4279-9d90-c8377509fd26.gif)

# 所感
雑にアプリケーション書いて雑にデプロイする環境を整えられてよかった。が、実際めんどいので、`git push heroku master`でアプリケーションが動くherokuがめっちゃ楽でめちゃ最高という感想をめちゃ抱いた。

アマゾンプライムビデオが始まってしまったので、プリズンブレイクシーズン３と4を見て消耗した。プリズンブレイク見てたら一週間終わってしまったという感じなのでストリーミングサービスやば過ぎンゴという気持ちでいっぱいです。

私からは以上です。




