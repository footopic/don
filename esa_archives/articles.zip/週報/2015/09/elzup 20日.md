---
title: "elzup 20日"
category: 週報/2015/09
tags: 
created_at: 2015-09-18 13:12:57 +0900
updated_at: 2015-09-21 18:15:49 +0900
published: true
---

# 今週の作業内容

## TweetLogサーバーの作成
位置情報付き感情評価済ツイートの収集(NICT, エリアストレス)
* rails で常時監視してTweetを保存するデーモンの作成
* atlantis.cps-lab.private にCentos サーバー立てました
* database は前回立てた db.cps-lab.private

## サーバーマニュアルの作成
@munisystem の作成してくれた itamae レシピ でのCentosサーバーの作成方法

## Gitlab バージョンアップデートを 「隣で見守った」

## 例のbot を再起動
少し **改良** した🙏
https://twitter.com/tdu12fi


## cps system 計画
* gitlab にて issue 管理
* プロモーションページの作成
* cps tutorial の作成
* ラボメンのサービス登録積みリスト
* ドキュメント管理の仕方
* etc... 計画中


## citylogAPI サーバーの拡張
* 任意カラムとしてセンサーの追加
* log レコードとAPIにproject_id を付与してプロジェクトごとに汎用化
* view をプロジェクトごとに見れるようにする,
* nginx でベーシック認証



## ブログ, Qiita
* percol_select_history - http://qiita.com/elzup/items/c22ae464f52715a17506
* pixiv インターン - http://elzup.hatenablog.com/entry/pixiv_intern_summer2015




# 知見, 得られた事
* rails 
    * 開発環境の分け方, env
    * taskの使い方
    * rails client 力
    * building.pry めっちゃ便利
    * clientを使った場合のDB設計とか
* codefights で python のメタプログラミング力がついている




# 発生した問題
*  ~~デレステをインストールしてしまった~~
* http://citylo.cps.im.dendai.ac.jp が production 環境でstatic ファイルが参照できない





# 来週の作業予定
```
優先順位
基本高い順に書く
必須再優先 🔥(:fire:) - 後回し 🌴(:palm_tree:)
```

## :fire: リアルタイムエリアストレス作成
* 感情解析のバッチ
* production 環境のデーモン起動
* view, 可視化部分
* API化

## :fire:  EC2015 参加
* EC2015 の準備
    * ポスター作成
    * サーバー再構築
    * ゲーム性の拡張
* 金曜日から北海道へ

## :fire: アーバンデータチャレンジLT発表資料の作成
* 9/29のアーバンデータチャレンジLTに向けて
* エリアストレスのLT作成

## citylogAPI サーバーの拡張
* production 環境でstatic ファイルを読みこませる, つまり主にスタイル適用

## :palm_tree: pixiv インターン成果物アプリの拡張
サービス公開に向けてにサーバーサイドのプロダクション環境の設計, フレームワークをcodeigniter から rails に移植



# 感想
pixiv インターン終わって一段落ついた(落ち着いたとは言っていない)
デレステ楽死い
codefights 楽死い
minecraft 楽死い
みんな Gitlab 使い初めていて内心嬉しい

